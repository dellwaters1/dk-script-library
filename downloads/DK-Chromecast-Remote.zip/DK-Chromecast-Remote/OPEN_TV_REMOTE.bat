@echo off
title Living Room TV Remote
cd /d "%~dp0"
set IP=192.168.1.157
adb connect %IP%:5555 >nul 2>&1
start "" "C:\Python314\pythonw.exe" "C:\Users\Dell\Desktop\Automation Creation Station\_System_Core\Active Scripts\Python Scripts\Cromcast_remote\CHROMECAST_NEST_REMOTE.pyw" --mini
