import sys
import os
import json
import subprocess
import threading
import time
import glob
import ctypes

# Running as .pyw under pythonw.exe leaves sys.stdout / sys.stderr as None,
# so any print() or library write would raise AttributeError and kill the app.
# Point them at the null device instead.
if sys.stdout is None or sys.stderr is None:
    _devnull = open(os.devnull, "w")
    if sys.stdout is None:
        sys.stdout = _devnull
    if sys.stderr is None:
        sys.stderr = _devnull

try:
    from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                                   QHBoxLayout, QPushButton, QLabel, QFrame, QStackedWidget,
                                   QScrollArea, QInputDialog, QFileDialog, QGraphicsDropShadowEffect,
                                   QGridLayout, QMessageBox, QSizeGrip, QMenu)
    from PySide6.QtCore import Qt, QPoint, QSize, QTimer, QThread, Signal, QObject, Slot
    from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPainterPath
except ImportError:
    print("PySide6 is not installed. Please install it with: pip install PySide6")
    sys.exit(1)

import asyncio
from androidtvremote2 import AndroidTVRemote, CannotConnect, ConnectionClosed, InvalidAuth
import logging

# --- Configuration & Memory ---
APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(APP_DIR, "remote_config.json")
MACROS_DIR = os.path.join(APP_DIR, "macros")
ACS_HUD_POS_FILE = r"C:\Users\Dell\Desktop\Automation Creation Station\_System_Core\acs_hud_position.json"
ACS_HUD_W, ACS_HUD_H = 200, 110
MINI_W, MINI_H = 130, 280
DOCK_MARGIN = 8

# Reverse map keycode int → name for readable macros
KEYCODE_NAMES = {v: k for k, v in {
    "BACK": 4, "HOME": 3, "UP": 19, "DOWN": 20, "LEFT": 21, "RIGHT": 22,
    "POWER": 26, "VOL_UP": 24, "VOL_DOWN": 25, "MUTE": 164, "SELECT": 23,
    "QUICK_SETTINGS": 83, "CHANNEL_UP": 166, "CHANNEL_DOWN": 167,
}.items()}

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {
        "last_ip": "GUSA2423035615",
        "x": 160,
        "y": 100,
        "protocol_mode": "adb",
        "docked": True,
        "free_x": None,
        "free_y": None,
    }

def save_config(ip, x, y, protocol_mode="adb", docked=None, free_x=None, free_y=None):
    try:
        cfg = load_config()
        cfg["last_ip"] = ip
        cfg["x"] = int(x)
        cfg["y"] = int(y)
        cfg["protocol_mode"] = protocol_mode
        if docked is not None:
            cfg["docked"] = bool(docked)
        if free_x is not None and free_y is not None:
            cfg["free_x"] = int(free_x)
            cfg["free_y"] = int(free_y)
        with open(CONFIG_FILE, 'w') as f:
            json.dump(cfg, f)
    except:
        pass

def secondary_bottom_right(width, height, margin=12):
    """Fallback: other monitor (or primary if alone), bottom-right."""
    app = QApplication.instance()
    screens = app.screens() if app else []
    if not screens:
        return 20, 20
    primary = app.primaryScreen() if app else None
    target = None
    for s in screens:
        if primary is None or s is not primary:
            target = s
            break
    if target is None:
        target = primary or screens[0]
    g = target.availableGeometry()
    x = g.x() + g.width() - width - margin
    y = g.y() + g.height() - height - margin
    return int(x), int(y)

def load_acs_hud_rect():
    """ACS OSD/HUD position (same file ACS_HUD.pyw writes)."""
    try:
        with open(ACS_HUD_POS_FILE, "r", encoding="utf-8-sig") as f:
            d = json.load(f)
            return int(d["x"]), int(d["y"]), ACS_HUD_W, ACS_HUD_H
    except Exception:
        x, y = secondary_bottom_right(ACS_HUD_W, ACS_HUD_H)
        return x, y, ACS_HUD_W, ACS_HUD_H

def dock_geometry_near_acs(mini_w=MINI_W, mini_h=MINI_H, margin=DOCK_MARGIN):
    app = QApplication.instance()
    screen = (app.primaryScreen() if app else None)
    if screen is None:
        return 0, 0
    g = screen.availableGeometry()
    x = g.x() + g.width() - mini_w - margin
    y = g.y() + g.height() - mini_h - 100
    return x, y

    # 1) Left of ACS, bottom-aligned with ACS bar
    x = ax - mini_w - margin
    y = ay + ah - mini_h

    # 2) No room on left → right of ACS
    if x < g.x() + 4:
        x = ax + aw + margin
        y = ay + ah - mini_h

    # 3) Still no room horizontally → directly above ACS
    if x + mini_w > g.x() + g.width() - 4 or x < g.x() + 4:
        x = ax + max(0, aw - mini_w)  # align toward ACS right edge
        y = ay - mini_h - margin

    # Clamp to the ACS monitor work area
    x = max(g.x() + 4, min(int(x), g.x() + g.width() - mini_w - 4))
    y = max(g.y() + 4, min(int(y), g.y() + g.height() - mini_h - 4))
    return int(x), int(y)

config = load_config()

# Parse Arguments
is_startup_mini = "--mini" in sys.argv
args_without_mini = [arg for arg in sys.argv if arg != "--mini"]
DEVICE_SERIAL = args_without_mini[1] if len(args_without_mini) > 1 and args_without_mini[1].strip() else config.get("last_ip", "GUSA2423035615")

# Saved position is permanent; only fall back if missing (set after QApp exists if needed)
REMOTE_START_X = int(config.get("x", 160))
REMOTE_START_Y = int(config.get("y", 100))
START_DOCKED = bool(config.get("docked", True))

PAUSE_SECONDS = 1.0
WINDOW_TITLE = "Chromecast Remote"

# --- ADB Keycodes ---
KEYCODES = {
    "BACK": 4,
    "HOME": 3,
    "UP": 19,
    "DOWN": 20,
    "LEFT": 21,
    "RIGHT": 22,
    "POWER": 26,
    "VOL_UP": 24,
    "VOL_DOWN": 25,
    "MUTE": 164,
    "SELECT": 23,
    "QUICK_SETTINGS": 83,
    "CHANNEL_UP": 166,
    "CHANNEL_DOWN": 167,
}

NEST_CAMERA_SEQUENCE = [
    KEYCODES["QUICK_SETTINGS"],
    KEYCODES["DOWN"],
    KEYCODES["DOWN"],
    KEYCODES["LEFT"],
    KEYCODES["SELECT"],
    KEYCODES["SELECT"],
    KEYCODES["SELECT"],
]

def bring_existing_remote_to_front():
    if sys.platform != "win32":
        return False
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, WINDOW_TITLE)
        if hwnd:
            SW_RESTORE = 9
            user32.ShowWindow(hwnd, SW_RESTORE)
            user32.SetForegroundWindow(hwnd)
            return True
    except Exception:
        pass
    return False

if bring_existing_remote_to_front():
    sys.exit(0)

# --- ADB Logic ---
def handle_adb_error(e):
    pass

def adb_connect_if_needed():
    if ":" not in DEVICE_SERIAL:
        return
    try:
        # CREATE_NO_WINDOW matters under pythonw.exe — without it every adb connect
        # flashes its own console window, which is exactly what the .pyw is meant to avoid.
        creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        subprocess.run(["adb", "connect", DEVICE_SERIAL], check=False, capture_output=True, text=True, timeout=5, creationflags=creationflags)
    except Exception as e:
        handle_adb_error(e)

is_recording = False
recorded_steps = []  # list of dict steps for v2 macros
last_action_time = None
_recording_window = None  # RemoteWindow ref while recording (for UI status)

def ensure_macros_dir():
    os.makedirs(MACROS_DIR, exist_ok=True)
    return MACROS_DIR

def _safe_macro_filename(label: str) -> str:
    raw = (label or "macro").strip()
    cleaned = "".join(ch if (ch.isalnum() or ch in (" ", "-", "_")) else "_" for ch in raw)
    cleaned = "_".join(cleaned.split())
    return (cleaned or "macro")[:80]

def record_step(step: dict):
    """Append one action with exact inter-action wait (perf_counter)."""
    global last_action_time, recorded_steps
    if not is_recording:
        return
    now = time.perf_counter()
    if last_action_time is not None:
        wait = now - last_action_time
        # Keep full precision; floor tiny noise under 5ms
        if wait < 0.005:
            wait = 0.0
        recorded_steps.append({"type": "sleep", "seconds": float(wait)})
    recorded_steps.append(step)
    last_action_time = now
    # Live feedback on the UI thread (button presses are already main-thread)
    if _recording_window is not None:
        try:
            action_n = sum(1 for s in recorded_steps if s.get("type") != "sleep")
            _recording_window.rec_status.setText(
                f"● RECORDING  ({action_n} actions)  — open Macros → Stop Rec"
            )
            _recording_window.setWindowTitle(f"{WINDOW_TITLE} · REC {action_n}")
        except Exception:
            pass

def adb_command(command_list, *, record=True):
    """Run raw ADB. Recording is usually done at send_key/launch_app level."""
    if record and is_recording:
        # Fallback path if something still calls adb_command directly while recording
        record_step({"type": "adb", "args": list(command_list)})

    try:
        adb_connect_if_needed()
        full_command = ["adb", "-s", DEVICE_SERIAL] + command_list
        creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        subprocess.run(full_command, check=False, capture_output=True, text=True, timeout=5, creationflags=creationflags)
    except Exception as e:
        handle_adb_error(e)

# --- Android TV Protocol Worker ---
class AndroidTVWorker(QObject):
    pairing_requested = Signal(str, str) # host, name
    pairing_failed = Signal()
    pairing_success = Signal()
    connection_status = Signal(bool)

    def __init__(self):
        super().__init__()
        self.remote = None
        self.loop = asyncio.new_event_loop()
        self.run_task = None
        self.host = None
        self.pairing_code = None
        self.pairing_event = None
        
        # Mapping ADB keycodes to Android TV keycodes
        self.key_map = {
            4: "BACK",
            3: "HOME",
            19: "DPAD_UP",
            20: "DPAD_DOWN",
            21: "DPAD_LEFT",
            22: "DPAD_RIGHT",
            26: "POWER",
            24: "VOLUME_UP",
            25: "VOLUME_DOWN",
            164: "VOLUME_MUTE",
            23: "DPAD_CENTER",
            83: "SETTINGS",
        }
        
        # Mapping Package names to URLs for Android TV
        self.app_urls = {
            "com.netflix.ninja": "https://www.netflix.com/title.*",
            "com.google.android.youtube.tv": "https://www.youtube.com",
            "com.disney.disneyplus": "https://www.disneyplus.com",
            "com.cbs.app": "https://www.paramountplus.com"
        }

    def start_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def set_host(self, host):
        self.host = host.split(":")[0] if ":" in host else host
        if self.remote:
            self.remote.disconnect()
        
        cert_file = os.path.join(os.path.dirname(__file__), "cert.pem")
        key_file = os.path.join(os.path.dirname(__file__), "key.pem")
        
        self.remote = AndroidTVRemote(
            "Chromecast Remote App", cert_file, key_file, self.host, loop=self.loop
        )
        if self.run_task:
            self.run_task.cancel()
        self.run_task = asyncio.run_coroutine_threadsafe(self.async_run(), self.loop)

    async def async_run(self):
        if not self.host: return
        self.pairing_event = asyncio.Event()
        
        if await self.remote.async_generate_cert_if_missing():
            await self.async_pair()

        while True:
            try:
                await self.remote.async_connect()
                self.connection_status.emit(True)
                break
            except InvalidAuth:
                await self.async_pair()
            except (CannotConnect, ConnectionClosed):
                self.connection_status.emit(False)
                await asyncio.sleep(2)
                
        self.remote.keep_reconnecting()

    async def async_pair(self):
        try:
            name, mac = await self.remote.async_get_name_and_mac()
            await self.remote.async_start_pairing()
            self.pairing_event.clear()
            self.pairing_requested.emit(self.host, name)
            await self.pairing_event.wait()
            
            if self.pairing_code:
                try:
                    await self.remote.async_finish_pairing(self.pairing_code)
                    self.pairing_success.emit()
                except Exception:
                    self.pairing_failed.emit()
            else:
                self.pairing_failed.emit()
                
        except Exception:
            self.pairing_failed.emit()
            
    def finish_pairing(self, code):
        self.pairing_code = code
        if self.pairing_event:
            self.loop.call_soon_threadsafe(self.pairing_event.set)

    def send_command(self, code):
        if not self.remote or not self.loop: return
        
        if isinstance(code, int) and code in self.key_map:
            asyncio.run_coroutine_threadsafe(self._send_key(self.key_map[code]), self.loop)
        elif isinstance(code, str) and code.startswith("http"):
            asyncio.run_coroutine_threadsafe(self._launch_app(code), self.loop)
        elif isinstance(code, str) and code == "ASSIST":
            asyncio.run_coroutine_threadsafe(self._send_key("ASSIST"), self.loop)

    async def _send_key(self, keycode_str):
        self.remote.send_key_command(keycode_str)
        
    async def _launch_app(self, url):
        self.remote.send_launch_app_command(url)

class AndroidTVThread(QThread):
    def __init__(self, worker):
        super().__init__()
        self.worker = worker

    def run(self):
        self.worker.start_loop()

# Global Worker Setup
atv_worker = AndroidTVWorker()
atv_thread = AndroidTVThread(atv_worker)
atv_thread.start()

def get_protocol_mode():
    return config.get("protocol_mode", "adb")

def set_protocol_mode(mode):
    config["protocol_mode"] = mode
    save_config(DEVICE_SERIAL, REMOTE_START_X, REMOTE_START_Y, mode)

def send_key(keycode):
    # Record protocol-agnostic key so macros replay on ADB or Android TV
    if is_recording:
        try:
            kc = int(keycode)
        except (TypeError, ValueError):
            kc = keycode
        name = KEYCODE_NAMES.get(kc, str(kc))
        record_step({"type": "key", "keycode": kc, "name": name})

    if get_protocol_mode() == "android_tv":
        atv_worker.send_command(keycode)
    else:
        adb_command(["shell", "input", "keyevent", str(keycode)], record=False)

def send_assistant_command():
    if is_recording:
        record_step({"type": "assist"})
    if get_protocol_mode() == "android_tv":
        atv_worker.send_command("ASSIST")
    else:
        adb_command(["shell", "am", "start", "-a", "android.intent.action.ASSIST"], record=False)

def open_quick_settings():
    send_key(KEYCODES["QUICK_SETTINGS"])

def launch_app(pkg):
    if is_recording:
        record_step({"type": "app", "package": pkg})
    if get_protocol_mode() == "android_tv":
        if pkg in atv_worker.app_urls:
            atv_worker.send_command(atv_worker.app_urls[pkg])
    else:
        adb_command(
            ["shell", "monkey", "-p", pkg, "-c", "android.intent.category.LAUNCHER", "1"],
            record=False,
        )

def run_nest_camera_macro():
    def worker():
        for key in NEST_CAMERA_SEQUENCE:
            send_key(key)
            time.sleep(PAUSE_SECONDS)
    threading.Thread(target=worker, daemon=True).start()

def _normalize_macro_steps(raw):
    """Accept v2 dict macros or legacy list-of-tuples JSON."""
    if isinstance(raw, dict) and "steps" in raw:
        return list(raw.get("steps") or [])
    if not isinstance(raw, list):
        return []
    steps = []
    for step in raw:
        # Legacy: ["sleep", 1.2] or ["adb", ["shell", ...]]
        if isinstance(step, (list, tuple)) and len(step) >= 2:
            kind = step[0]
            if kind == "sleep":
                steps.append({"type": "sleep", "seconds": float(step[1])})
            elif kind == "adb":
                steps.append({"type": "adb", "args": list(step[1])})
            else:
                steps.append({"type": str(kind), "value": step[1]})
        elif isinstance(step, dict) and step.get("type"):
            steps.append(step)
    return steps

def _play_step(step):
    """Execute one normalized step on the current protocol."""
    stype = step.get("type")
    if stype == "sleep":
        time.sleep(max(0.0, float(step.get("seconds", 0))))
        return
    if stype == "key":
        kc = step.get("keycode")
        if kc is None:
            return
        if get_protocol_mode() == "android_tv":
            atv_worker.send_command(int(kc))
        else:
            adb_command(["shell", "input", "keyevent", str(kc)], record=False)
        return
    if stype == "assist":
        if get_protocol_mode() == "android_tv":
            atv_worker.send_command("ASSIST")
        else:
            adb_command(["shell", "am", "start", "-a", "android.intent.action.ASSIST"], record=False)
        return
    if stype == "app":
        pkg = step.get("package")
        if not pkg:
            return
        if get_protocol_mode() == "android_tv":
            if pkg in atv_worker.app_urls:
                atv_worker.send_command(atv_worker.app_urls[pkg])
        else:
            adb_command(
                ["shell", "monkey", "-p", pkg, "-c", "android.intent.category.LAUNCHER", "1"],
                record=False,
            )
        return
    if stype == "adb":
        args = step.get("args") or []
        if get_protocol_mode() == "android_tv" and "keyevent" in args:
            try:
                idx = args.index("keyevent")
                kc = int(args[idx + 1])
                atv_worker.send_command(kc)
            except Exception:
                pass
        else:
            adb_command(list(args), record=False)
        return

def play_macro_file(path, on_finished=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except Exception:
        return
    steps = _normalize_macro_steps(raw)
    if not steps:
        return

    def worker():
        # Snapshot flag — never record while replaying
        global is_recording
        saved_rec = is_recording
        is_recording = False
        try:
            for step in steps:
                try:
                    _play_step(step)
                except Exception:
                    pass
        finally:
            is_recording = saved_rec
            if on_finished:
                try:
                    on_finished()
                except Exception:
                    pass

    threading.Thread(target=worker, daemon=True).start()

def list_saved_macros():
    """Return [(label, path), ...] from macros/ only (not remote_config)."""
    ensure_macros_dir()
    items = []
    for f in sorted(glob.glob(os.path.join(MACROS_DIR, "*.json"))):
        label = os.path.splitext(os.path.basename(f))[0]
        try:
            with open(f, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict) and data.get("name"):
                label = str(data["name"])
        except Exception:
            pass
        items.append((label, f))
    return items

def save_macro_labeled(label, steps):
    """Write a v2 macro JSON with label; returns path."""
    ensure_macros_dir()
    base = _safe_macro_filename(label)
    path = os.path.join(MACROS_DIR, base + ".json")
    # Avoid overwrite clobber without suffix
    if os.path.exists(path):
        n = 2
        while os.path.exists(os.path.join(MACROS_DIR, f"{base}_{n}.json")):
            n += 1
        path = os.path.join(MACROS_DIR, f"{base}_{n}.json")
    payload = {
        "name": label.strip() or base,
        "version": 2,
        "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "protocol_at_record": get_protocol_mode(),
        "steps": steps,
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return path

# --- Local HTTP Server for AHK API ---
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

class LocalRemoteHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        query_components = parse_qs(urlparse(self.path).query)
        if "key" in query_components:
            raw_key = query_components["key"][0]
            key_name = raw_key.upper()
            # NEST = full nest camera macro in one call
            if key_name == "NEST":
                threading.Thread(target=run_nest_camera_macro, daemon=True).start()
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"OK")
                return
            # MACRO_<Label> = play a saved macro from macros/ folder
            if key_name.startswith("MACRO_"):
                wanted = key_name[len("MACRO_"):]
                for label, path in list_saved_macros():
                    if label.upper().replace(" ", "_") == wanted:
                        threading.Thread(target=play_macro_file, args=(path,), daemon=True).start()
                        self.send_response(200)
                        self.end_headers()
                        self.wfile.write(b"OK")
                        return
            # APP_<package> = launch an app (case preserved for package name)
            if key_name.startswith("APP_"):
                pkg = raw_key[len("APP_"):]
                launch_app(pkg)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"OK")
                return
            if key_name in KEYCODES:
                send_key(KEYCODES[key_name])
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"OK")
                return
        self.send_response(400)
        self.end_headers()
        self.wfile.write(b"Bad Request")
        
    def log_message(self, format, *args):
        pass # Suppress logging

def start_local_server():
    try:
        server = HTTPServer(('', 9090), LocalRemoteHandler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
    except Exception:
        pass

start_local_server()

# --- Custom Qt Widgets ---
class CircularButton(QPushButton):
    def __init__(self, text, size=45, base_color="#ffffff", grad_bottom="#e8eaed", text_color="#202124", font_size=12, is_bold=True, parent=None):
        super().__init__(text, parent)
        self.setFixedSize(size, size)
        bold_str = "bold" if is_bold else "normal"
        
        if base_color == "#ffffff":
            b_top = "rgba(255,255,255,0.9)"
            b_bot = "rgba(0,0,0,0.15)"
        else:
            b_top = "rgba(255,255,255,0.15)"
            b_bot = "rgba(0,0,0,0.4)"

        self.setStyleSheet(f"""
            QPushButton {{
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {base_color}, stop:1 {grad_bottom});
                color: {text_color};
                border-radius: {size // 2}px;
                border-top: 1px solid {b_top};
                border-bottom: 2px solid {b_bot};
                border-left: 1px solid rgba(0,0,0,0.05);
                border-right: 1px solid rgba(0,0,0,0.05);
                font-family: 'Segoe UI', Arial, sans-serif;
                font-size: {font_size}px;
                font-weight: {bold_str};
            }}
            QPushButton:hover {{
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {grad_bottom}, stop:1 {base_color});
            }}
            QPushButton:pressed {{
                background: {grad_bottom};
                border-top: 2px solid {b_bot};
                border-bottom: 1px solid {b_top};
            }}
        """)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(8)
        shadow.setColor(QColor(0, 0, 0, 40))
        shadow.setOffset(0, 3)
        self.setGraphicsEffect(shadow)

class PillButton(QPushButton):
    def __init__(self, text, width=100, height=40, base_color="#ffffff", grad_bottom="#e8eaed", text_color="#202124", font_size=11, parent=None):
        super().__init__(text, parent)
        self.setFixedSize(width, height)
        b_top = "rgba(255,255,255,0.9)"
        b_bot = "rgba(0,0,0,0.15)"
        self.setStyleSheet(f"""
            QPushButton {{
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {base_color}, stop:1 {grad_bottom});
                color: {text_color};
                border-radius: {height // 2}px;
                border-top: 1px solid {b_top};
                border-bottom: 2px solid {b_bot};
                font-family: 'Segoe UI', Arial, sans-serif;
                font-size: {font_size}px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {grad_bottom}, stop:1 {base_color});
            }}
            QPushButton:pressed {{
                background: {grad_bottom};
                border-top: 2px solid {b_bot};
                border-bottom: 1px solid {b_top};
            }}
        """)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(8)
        shadow.setColor(QColor(0, 0, 0, 40))
        shadow.setOffset(0, 3)
        self.setGraphicsEffect(shadow)

class VerticalRocker(QFrame):
    def __init__(self, top_text, bottom_text, top_cmd, bottom_cmd, parent=None):
        super().__init__(parent)
        self.setFixedSize(45, 110)
        self.setStyleSheet("""
            QFrame { 
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ffffff, stop:1 #e0e0e0);
                border-radius: 22px; 
                border-top: 1px solid rgba(255,255,255,0.9);
                border-bottom: 2px solid rgba(0,0,0,0.2);
                border-right: 1px solid rgba(0,0,0,0.1);
            }
        """)
        
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(8)
        shadow.setColor(QColor(0, 0, 0, 40))
        shadow.setOffset(0, 3)
        self.setGraphicsEffect(shadow)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        btn_top = QPushButton(top_text)
        btn_top.setFixedSize(45, 55)
        btn_top.setStyleSheet("QPushButton { background: transparent; border: none; font-size: 18px; font-weight: bold; color: #5f6368; } QPushButton:pressed { background: rgba(0,0,0,0.05); border-top-left-radius: 22px; border-top-right-radius: 22px; }")
        btn_top.clicked.connect(top_cmd)
        
        btn_bot = QPushButton(bottom_text)
        btn_bot.setFixedSize(45, 55)
        btn_bot.setStyleSheet("QPushButton { background: transparent; border: none; font-size: 20px; font-weight: bold; color: #5f6368; } QPushButton:pressed { background: rgba(0,0,0,0.05); border-bottom-left-radius: 22px; border-bottom-right-radius: 22px; }")
        btn_bot.clicked.connect(bottom_cmd)
        
        layout.addWidget(btn_top)
        layout.addWidget(btn_bot)

class MiniRocker(QFrame):
    def __init__(self, top_text, bottom_text, top_cmd, bottom_cmd, parent=None):
        super().__init__(parent)
        self.setFixedSize(22, 50)
        self.setStyleSheet("""
            QFrame { 
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ffffff, stop:1 #e0e0e0);
                border-radius: 11px; 
                border: 1px solid rgba(0,0,0,0.1);
            }
        """)
        rl = QVBoxLayout(self)
        rl.setContentsMargins(0,0,0,0)
        rl.setSpacing(0)
        b1 = QPushButton(top_text)
        b1.setFixedSize(22,25)
        b1.setStyleSheet("QPushButton { background: transparent; border: none; font-size: 10px; font-weight: bold; color: #5f6368; } QPushButton:pressed { background: rgba(0,0,0,0.05); border-top-left-radius: 11px; border-top-right-radius: 11px; }")
        b1.clicked.connect(top_cmd)
        b2 = QPushButton(bottom_text)
        b2.setFixedSize(22,25)
        b2.setStyleSheet("QPushButton { background: transparent; border: none; font-size: 10px; font-weight: bold; color: #5f6368; } QPushButton:pressed { background: rgba(0,0,0,0.05); border-bottom-left-radius: 11px; border-bottom-right-radius: 11px; }")
        b2.clicked.connect(bottom_cmd)
        rl.addWidget(b1)
        rl.addWidget(b2)

class DPadWidget(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(190, 190)
        
        self.setStyleSheet("""
            QFrame {
                background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 #4a4a4a, stop:1 #1e1e1e);
                border-radius: 95px;
                border-top: 1px solid #111;
                border-bottom: 2px solid rgba(255,255,255,0.3);
            }
        """)
        
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(10)
        shadow.setColor(QColor(0, 0, 0, 60))
        shadow.setOffset(0, 2)
        self.setGraphicsEffect(shadow)

        layout = QGridLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        style = """
            QPushButton { background: transparent; color: #ffffff; border: none; font-size: 14px; }
            QPushButton:pressed { background: rgba(255,255,255,0.1); border-radius: 25px; }
        """
        up_btn = QPushButton("▲")
        up_btn.setFixedSize(50, 50)
        up_btn.setStyleSheet(style)
        
        down_btn = QPushButton("▼")
        down_btn.setFixedSize(50, 50)
        down_btn.setStyleSheet(style)
        
        left_btn = QPushButton("◀")
        left_btn.setFixedSize(50, 50)
        left_btn.setStyleSheet(style)
        
        right_btn = QPushButton("▶")
        right_btn.setFixedSize(50, 50)
        right_btn.setStyleSheet(style)

        center_btn = CircularButton("OK", 65, "#ffffff", "#e0e0e0", "#202124", 14)

        up_btn.clicked.connect(lambda: send_key(KEYCODES["UP"]))
        down_btn.clicked.connect(lambda: send_key(KEYCODES["DOWN"]))
        left_btn.clicked.connect(lambda: send_key(KEYCODES["LEFT"]))
        right_btn.clicked.connect(lambda: send_key(KEYCODES["RIGHT"]))
        center_btn.clicked.connect(lambda: send_key(KEYCODES["SELECT"]))

        layout.addWidget(up_btn, 0, 1, alignment=Qt.AlignCenter)
        layout.addWidget(left_btn, 1, 0, alignment=Qt.AlignCenter)
        layout.addWidget(center_btn, 1, 1, alignment=Qt.AlignCenter)
        layout.addWidget(right_btn, 1, 2, alignment=Qt.AlignCenter)
        layout.addWidget(down_btn, 2, 1, alignment=Qt.AlignCenter)

class MiniDPad(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(80, 80)
        self.setStyleSheet("""
            QFrame {
                background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 #4a4a4a, stop:1 #1e1e1e);
                border-radius: 40px;
                border-top: 1px solid #111;
                border-bottom: 1px solid rgba(255,255,255,0.3);
            }
        """)
        dl = QGridLayout(self)
        dl.setContentsMargins(0,0,0,0)
        dl.setSpacing(0)
        
        style = "QPushButton { background: transparent; color: white; border: none; font-size: 8px; } QPushButton:pressed { background: rgba(255,255,255,0.1); border-radius: 10px; }"
        u = QPushButton("▲"); u.setFixedSize(20,20); u.setStyleSheet(style)
        d = QPushButton("▼"); d.setFixedSize(20,20); d.setStyleSheet(style)
        l = QPushButton("◀"); l.setFixedSize(20,20); l.setStyleSheet(style)
        r = QPushButton("▶"); r.setFixedSize(20,20); r.setStyleSheet(style)
        c = CircularButton("OK", 28, "#ffffff", "#e0e0e0", "#202124", 8)
        
        u.clicked.connect(lambda: send_key(KEYCODES["UP"]))
        d.clicked.connect(lambda: send_key(KEYCODES["DOWN"]))
        l.clicked.connect(lambda: send_key(KEYCODES["LEFT"]))
        r.clicked.connect(lambda: send_key(KEYCODES["RIGHT"]))
        c.clicked.connect(lambda: send_key(KEYCODES["SELECT"]))
        
        dl.addWidget(u, 0, 1, alignment=Qt.AlignCenter)
        dl.addWidget(l, 1, 0, alignment=Qt.AlignCenter)
        dl.addWidget(c, 1, 1, alignment=Qt.AlignCenter)
        dl.addWidget(r, 1, 2, alignment=Qt.AlignCenter)
        dl.addWidget(d, 2, 1, alignment=Qt.AlignCenter)

# --- Main Application Window ---
class RemoteWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(WINDOW_TITLE)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        self.old_pos = None
        self.saved_geometry = None
        self.is_minimized = False
        self.is_docked = False  # mini only: snapped next to ACS HUD
        self._drag_moved = False
        self._press_button = None
        
        self.setup_ui()
        self.setGeometry(REMOTE_START_X, REMOTE_START_Y, 250, 820)
        
        if is_startup_mini:
            # Boot as mini: docked beside ACS by default (or last free spot if undocked)
            self.enter_mini(docked=START_DOCKED)
            # Permanence: re-snap to ACS after desktop settles (monitors / HUD late-start)
            if START_DOCKED:
                QTimer.singleShot(2500, self.dock_to_acs)
                QTimer.singleShot(8000, self.dock_to_acs)
                # Keep docked remote glued to ACS if HUD moves
                self._dock_timer = QTimer(self)
                self._dock_timer.setInterval(15000)
                self._dock_timer.timeout.connect(self._redock_if_needed)
                self._dock_timer.start()
            
        atv_worker.pairing_requested.connect(self.prompt_pairing_pin)
        atv_worker.pairing_failed.connect(self.on_pairing_failed)
        atv_worker.pairing_success.connect(self.on_pairing_success)
        atv_worker.connection_status.connect(self.on_connection_status)
        
        # Initialize Android TV remote if configured
        if get_protocol_mode() == "android_tv":
            atv_worker.set_host(DEVICE_SERIAL)

    @Slot(str, str)
    def prompt_pairing_pin(self, host, name):
        text, ok = QInputDialog.getText(self, "Pairing Required", f"Enter PIN displayed on {name} ({host}):")
        if ok and text.strip():
            atv_worker.finish_pairing(text.strip())
        else:
            atv_worker.finish_pairing(None)
            
    @Slot()
    def on_pairing_failed(self):
        QMessageBox.warning(self, "Pairing Failed", "Failed to pair with Android TV. Please try again or switch to ADB.")
        
    @Slot()
    def on_pairing_success(self):
        QMessageBox.information(self, "Pairing Success", "Successfully paired with Android TV!")
        
    @Slot(bool)
    def on_connection_status(self, connected):
        if hasattr(self, 'mode_btn'):
            if connected:
                self.mode_btn.setStyleSheet(self.mode_btn.styleSheet().replace("color: #e53935", "color: #43a047").replace("color: #202124", "color: #43a047"))
            else:
                self.mode_btn.setStyleSheet(self.mode_btn.styleSheet().replace("color: #43a047", "color: #e53935").replace("color: #202124", "color: #e53935"))

    def setup_ui(self):
        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)
        
        self.main_layout = QVBoxLayout(self.central_widget)
        self.main_layout.setContentsMargins(10, 10, 10, 10)
        
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(25)
        shadow.setColor(QColor(0, 0, 0, 120))
        shadow.setOffset(0, 8)
        
        self.remote_body = QFrame()
        self.remote_body.setAttribute(Qt.WA_TranslucentBackground, True)
        self.remote_body.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #ffffff, stop:1 #ececec);
                border-radius: 999px;
                border: 1px solid rgba(0,0,0,0.08);
            }
        """)
        self.remote_body.setGraphicsEffect(shadow)
        
        self.body_layout = QVBoxLayout(self.remote_body)
        self.body_layout.setContentsMargins(20, 46, 20, 46)
        
        self.stacked_widget = QStackedWidget()
        self.body_layout.addWidget(self.stacked_widget)
        
        self.build_remote_page()
        self.build_macros_page()
        
        self.main_layout.addWidget(self.remote_body)

        self.size_grip = QSizeGrip(self)
        self.main_layout.addWidget(self.size_grip, alignment=Qt.AlignBottom | Qt.AlignRight)
        self.size_grip.setToolTip("Drag to resize the remote")

        # --- Fully Functional Miniature Remote ---
        self.mini_body = QFrame()
        self.mini_body.setFixedSize(110, 260)
        self.mini_body.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #ffffff, stop:1 #ececec);
                border-radius: 55px;
                border: 1px solid rgba(0,0,0,0.1);
            }
        """)
        self.mini_body.setGraphicsEffect(shadow)
        
        self.mini_layout = QVBoxLayout(self.mini_body)
        self.mini_layout.setContentsMargins(15, 20, 15, 20)
        self.mini_layout.setSpacing(5)
        self.mini_layout.setAlignment(Qt.AlignTop)
        
        r1 = QHBoxLayout()
        mini_pwr = CircularButton("⏻", 22, font_size=8)
        mini_pwr.clicked.connect(lambda: send_key(KEYCODES["POWER"]))
        mini_pwr.setStyleSheet(mini_pwr.styleSheet().replace("color: #202124", "color: #5f6368"))
        mini_inp = CircularButton("→", 22, font_size=8)
        mini_inp.clicked.connect(open_quick_settings)
        mini_inp.setStyleSheet(mini_inp.styleSheet().replace("color: #202124", "color: #5f6368"))
        r1.addWidget(mini_pwr)
        r1.addStretch()
        r1.addWidget(mini_inp)
        self.mini_layout.addLayout(r1)
        
        r2 = QHBoxLayout()
        mini_ast = CircularButton("✨", 28, "#303134", "#1e1e1e", "#ffffff", 12)
        mini_ast.clicked.connect(send_assistant_command)
        r2.addStretch()
        r2.addWidget(mini_ast)
        r2.addStretch()
        self.mini_layout.addLayout(r2)
        
        dpad_layout = QHBoxLayout()
        dpad_layout.addWidget(MiniDPad())
        self.mini_layout.addLayout(dpad_layout)
        
        r4 = QHBoxLayout()
        mini_back = CircularButton("←", 24, font_size=10)
        mini_back.clicked.connect(lambda: send_key(KEYCODES["BACK"]))
        mini_back.setStyleSheet(mini_back.styleSheet().replace("color: #202124", "color: #5f6368"))
        mini_home = CircularButton("⌂", 26, "#303134", "#1e1e1e", "#ffffff", 12)
        mini_home.clicked.connect(lambda: send_key(KEYCODES["HOME"]))
        mini_live = CircularButton("📺", 24, font_size=8)
        mini_live.setStyleSheet(mini_live.styleSheet().replace("color: #202124", "color: #5f6368"))
        r4.addWidget(mini_back)
        r4.addWidget(mini_home)
        r4.addWidget(mini_live)
        self.mini_layout.addLayout(r4)
        
        r5 = QHBoxLayout()
        m_vol = MiniRocker("+", "-", lambda: send_key(KEYCODES["VOL_UP"]), lambda: send_key(KEYCODES["VOL_DOWN"]))
        m_nest = CircularButton("NST", 24, base_color="#e53935", grad_bottom="#b71c1c", text_color="#ffffff", font_size=7)
        m_nest.clicked.connect(run_nest_camera_macro)
        m_ch = MiniRocker("∧", "∨", lambda: send_key(KEYCODES["CHANNEL_UP"]), lambda: send_key(KEYCODES["CHANNEL_DOWN"]))
        r5.addWidget(m_vol)
        r5.addStretch()
        r5.addWidget(m_nest)
        r5.addStretch()
        r5.addWidget(m_ch)
        self.mini_layout.addLayout(r5)
        
        self.main_layout.addWidget(self.mini_body)
        self.mini_body.hide()

        # --- Hidden Body ---
        self.hidden_body = QFrame(self)
        self.hidden_body.setStyleSheet("background-color: rgba(0, 0, 0, 128); border-radius: 48px;")
        hl = QVBoxLayout(self.hidden_body)
        hl.setContentsMargins(0, 0, 0, 0)
        lbl = QLabel("Chromecast", self.hidden_body)
        lbl.setStyleSheet("color: white; font-weight: bold; font-size: 16px; background: transparent;")
        lbl.setAlignment(Qt.AlignCenter)
        hl.addWidget(lbl)
        self.hidden_body.hide()
        
        # Click to restore
        self.hidden_body.mousePressEvent = lambda e: self.exit_hidden()

    def build_remote_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(12)
        layout.setAlignment(Qt.AlignTop)

        row1 = QHBoxLayout()
        pwr = CircularButton("⏻", 35, font_size=14)
        pwr.clicked.connect(lambda: send_key(KEYCODES["POWER"]))
        pwr.setStyleSheet(pwr.styleSheet().replace("color: #202124", "color: #5f6368"))
        pwr.setToolTip("Power")
        
        inp = CircularButton("→", 35, font_size=14)
        inp.clicked.connect(open_quick_settings)
        inp.setStyleSheet(inp.styleSheet().replace("color: #202124", "color: #5f6368"))
        inp.setToolTip("Input / Quick Settings")
        
        row1.addWidget(pwr)
        row1.addStretch()
        row1.addWidget(inp)
        layout.addLayout(row1)

        row2 = QHBoxLayout()
        user = CircularButton("👤", 40, font_size=14)
        user.setStyleSheet(user.styleSheet().replace("color: #202124", "color: #5f6368"))
        user.setToolTip("User Profile")
        
        ast = CircularButton("✨", 45, "#303134", "#1e1e1e", "#ffffff", 18)
        ast.clicked.connect(send_assistant_command)
        ast.setToolTip("Google Assistant / Gemini")
        
        set_btn = CircularButton("⚙", 40, font_size=14)
        set_btn.clicked.connect(open_quick_settings)
        set_btn.setStyleSheet(set_btn.styleSheet().replace("color: #202124", "color: #5f6368"))
        set_btn.setToolTip("Settings")
        
        row2.addWidget(user)
        row2.addStretch()
        row2.addWidget(ast)
        row2.addStretch()
        row2.addWidget(set_btn)
        layout.addLayout(row2)

        dpad_layout = QHBoxLayout()
        dpad_layout.addWidget(DPadWidget())
        layout.addLayout(dpad_layout)

        row4 = QHBoxLayout()
        back = CircularButton("←", 40, font_size=16)
        back.clicked.connect(lambda: send_key(KEYCODES["BACK"]))
        back.setStyleSheet(back.styleSheet().replace("color: #202124", "color: #5f6368"))
        back.setToolTip("Back")
        
        home = CircularButton("⌂", 45, "#303134", "#1e1e1e", "#ffffff", 18)
        home.clicked.connect(lambda: send_key(KEYCODES["HOME"]))
        home.setToolTip("Home")
        
        live = CircularButton("📺", 40, font_size=14)
        live.setStyleSheet(live.styleSheet().replace("color: #202124", "color: #5f6368"))
        live.setToolTip("Live TV")
        
        row4.addWidget(back)
        row4.addStretch()
        row4.addWidget(home)
        row4.addStretch()
        row4.addWidget(live)
        layout.addLayout(row4)

        row5 = QHBoxLayout()
        vol_rocker = VerticalRocker("+", "-", lambda: send_key(KEYCODES["VOL_UP"]), lambda: send_key(KEYCODES["VOL_DOWN"]))
        vol_rocker.setToolTip("Volume Up/Down")
        
        # User requested Nest Cam to be exactly where Mute was.
        nest = CircularButton("NEST", 40, base_color="#e53935", grad_bottom="#b71c1c", text_color="#ffffff", font_size=10)
        nest.clicked.connect(run_nest_camera_macro)
        nest.setToolTip("Launch Nest Camera Macro")
        
        ch_rocker = VerticalRocker("∧", "∨", lambda: send_key(KEYCODES["CHANNEL_UP"]), lambda: send_key(KEYCODES["CHANNEL_DOWN"]))
        ch_rocker.setToolTip("Channel Up/Down")
        
        row5.addWidget(vol_rocker)
        row5.addStretch()
        row5.addWidget(nest)
        row5.addStretch()
        row5.addWidget(ch_rocker)
        layout.addLayout(row5)

        layout.addSpacing(5)

        apps1 = QHBoxLayout()
        net_btn = PillButton("NETFLIX", 100, 35, font_size=10, text_color="#E50914")
        net_btn.clicked.connect(lambda: launch_app("com.netflix.ninja"))
        net_btn.setToolTip("Launch Netflix")
        
        yt_btn = PillButton("YouTube", 100, 35, font_size=10, text_color="#FF0000")
        yt_btn.clicked.connect(lambda: launch_app("com.google.android.youtube.tv"))
        yt_btn.setToolTip("Launch YouTube")
        
        apps1.addWidget(net_btn)
        apps1.addWidget(yt_btn)
        layout.addLayout(apps1)

        apps2 = QHBoxLayout()
        dis_btn = PillButton("Disney+", 100, 35, font_size=10, text_color="#113CCF")
        dis_btn.clicked.connect(lambda: launch_app("com.disney.disneyplus"))
        dis_btn.setToolTip("Launch Disney+")
        
        par_btn = PillButton("Paramount+", 100, 35, font_size=10, text_color="#0064FF")
        par_btn.clicked.connect(lambda: launch_app("com.cbs.app"))
        par_btn.setToolTip("Launch Paramount+")
        
        apps2.addWidget(dis_btn)
        apps2.addWidget(par_btn)
        layout.addLayout(apps2)
        
        layout.addSpacing(5)

        utils = QHBoxLayout()
        
        self.mac_btn = PillButton("Macros", 70, 30, font_size=10)
        self.mac_btn.clicked.connect(self.on_macros_button)
        self.mac_btn.setToolTip("Open Saved Macros (while recording: stop & name)")
        
        min_b = PillButton("Mini", 70, 30, font_size=10)
        min_b.clicked.connect(lambda: self.enter_mini(docked=True))
        min_b.setToolTip("Mini remote docked beside ACS OSD (double-click undocks)")
        
        hide = PillButton("Close", 70, 30, font_size=10)
        hide.clicked.connect(self.close)
        hide.setToolTip("Close / Hide Remote")
        
        utils.addStretch()
        utils.addWidget(self.mac_btn)
        utils.addWidget(min_b)
        utils.addWidget(hide)
        utils.addStretch()
        layout.addLayout(utils)

        brand = QLabel("Dell's Chromecast")
        brand.setStyleSheet("color: #5f6368; font-size: 14px; font-weight: 900; font-family: 'Arial Black', sans-serif;")
        brand.setAlignment(Qt.AlignCenter)
        layout.addSpacing(5)
        layout.addWidget(brand)
        
        # IP Change Button
        ip_btn = PillButton("Set Target IP", 120, 25, font_size=9)
        ip_btn.clicked.connect(self.prompt_update_ip)
        ip_btn.setToolTip("Change the Target IP / Device")
        layout.addWidget(ip_btn, alignment=Qt.AlignCenter)
        
        layout.addSpacing(5)
        
        # Protocol Toggle Button
        current_mode = "Android TV" if get_protocol_mode() == "android_tv" else "ADB"
        self.mode_btn = PillButton(f"Mode: {current_mode}", 140, 30, font_size=9)
        self.mode_btn.clicked.connect(self.toggle_protocol_mode)
        self.mode_btn.setToolTip("Toggle between ADB and Android TV protocol")
        layout.addWidget(self.mode_btn, alignment=Qt.AlignCenter)

        self.stacked_widget.addWidget(page)

    def toggle_protocol_mode(self):
        if get_protocol_mode() == "adb":
            set_protocol_mode("android_tv")
            self.mode_btn.setText("Mode: Android TV")
            atv_worker.set_host(DEVICE_SERIAL)
        else:
            set_protocol_mode("adb")
            self.mode_btn.setText("Mode: ADB")
            self.mode_btn.setStyleSheet(self.mode_btn.styleSheet().replace("color: #43a047", "color: #202124").replace("color: #e53935", "color: #202124"))
            if atv_worker.remote:
                atv_worker.remote.disconnect()

    def build_macros_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)

        back_btn = PillButton("⬅ Back", 210, 45, font_size=11)
        back_btn.clicked.connect(lambda: self.stacked_widget.setCurrentIndex(0))
        back_btn.setToolTip("Go back to the main remote screen")
        layout.addWidget(back_btn, alignment=Qt.AlignCenter)

        layout.addSpacing(6)

        hint = QLabel("Tap a macro → runs exact timing, then docks")
        hint.setStyleSheet("color: #5f6368; font-size: 10px;")
        hint.setAlignment(Qt.AlignCenter)
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self.rec_btn = PillButton("Rec Macro", 210, 40, "#ffebee", "#ef9a9a", "#c62828")
        self.rec_btn.clicked.connect(self.toggle_recording)
        self.rec_btn.setToolTip(
            "Record every button with exact wait times between presses. "
            "Press Stop Rec, then type a label."
        )
        layout.addWidget(self.rec_btn, alignment=Qt.AlignCenter)

        self.rec_status = QLabel("")
        self.rec_status.setStyleSheet("color: #c62828; font-size: 10px; font-weight: bold;")
        self.rec_status.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.rec_status)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet(
            "QScrollArea { border: none; background-color: transparent; } "
            "QWidget { background-color: transparent; }"
        )

        self.macros_content = QWidget()
        self.macros_layout = QVBoxLayout(self.macros_content)
        self.macros_layout.setAlignment(Qt.AlignTop)
        self.macros_layout.setSpacing(8)
        scroll.setWidget(self.macros_content)

        layout.addWidget(scroll)
        self.stacked_widget.addWidget(page)
        ensure_macros_dir()

    def prompt_update_ip(self):
        global DEVICE_SERIAL
        text, ok = QInputDialog.getText(self, "Update Target", "Enter full device IP and port (e.g. 192.168.1.169:5555):", text=DEVICE_SERIAL)
        if ok and text.strip():
            DEVICE_SERIAL = text.strip()
            save_config(DEVICE_SERIAL, self.x(), self.y())
            print(f"Target set to: {DEVICE_SERIAL}")

    def _clear_macros_layout(self):
        while self.macros_layout.count():
            item = self.macros_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def refresh_macros_list(self):
        """Rebuild labeled play buttons from macros/ folder."""
        self._clear_macros_layout()
        macros = list_saved_macros()
        if not macros:
            empty = QLabel("No macros yet.\nRec Macro → press buttons → Stop → name it.")
            empty.setStyleSheet("color: #5f6368; font-size: 11px;")
            empty.setAlignment(Qt.AlignCenter)
            empty.setWordWrap(True)
            self.macros_layout.addWidget(empty)
            return

        for label, path in macros:
            row = QHBoxLayout()
            row.setSpacing(4)
            # Truncate long labels for button width
            btn_text = label if len(label) <= 18 else label[:16] + "…"
            play_btn = PillButton(btn_text, 170, 42, font_size=10)
            play_btn.setToolTip(f"Play “{label}” with exact waits, then dock mini remote")
            play_btn.clicked.connect(lambda checked=False, p=path, n=label: self.play_macro_and_dock(p, n))
            row.addWidget(play_btn)

            del_btn = CircularButton("✕", 28, "#ffebee", "#ef9a9a", "#c62828", 11)
            del_btn.setToolTip(f"Delete “{label}”")
            del_btn.clicked.connect(lambda checked=False, p=path, n=label: self.delete_macro(p, n))
            row.addWidget(del_btn)

            wrap = QWidget()
            wrap.setLayout(row)
            self.macros_layout.addWidget(wrap, alignment=Qt.AlignCenter)

    def on_macros_button(self):
        """Macros button: if recording, stop+label; else open macros list."""
        if is_recording:
            self.toggle_recording()
            return
        self.open_macros_page()

    def open_macros_page(self):
        self.refresh_macros_list()
        self.stacked_widget.setCurrentIndex(1)

    def play_macro_and_dock(self, path, label=None):
        """Run saved macro (exact waits) and collapse remote into ACS dock."""
        # Dock immediately so full remote is out of the way while sequence runs
        self.enter_mini(docked=True)
        play_macro_file(path)

    def delete_macro(self, path, label):
        reply = QMessageBox.question(
            self,
            "Delete Macro",
            f"Delete “{label}”?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        try:
            os.remove(path)
        except Exception as e:
            QMessageBox.warning(self, "Delete Failed", str(e))
            return
        self.refresh_macros_list()

    def _set_recording_ui(self, active: bool, step_count: int = 0):
        if active:
            self.rec_btn.setText("Stop Rec")
            # Force a red “recording” look without fragile stylesheet replace chains
            self.rec_btn.setStyleSheet(
                self.rec_btn.styleSheet()  # keep base
            )
            self.rec_status.setText(f"● RECORDING  ({step_count} actions)  — press Stop when done")
            self.rec_status.setStyleSheet("color: #c62828; font-size: 10px; font-weight: bold;")
        else:
            self.rec_btn.setText("Rec Macro")
            self.rec_status.setText("")
            self.rec_status.setStyleSheet("color: #5f6368; font-size: 10px;")

    def toggle_recording(self):
        global is_recording, recorded_steps, last_action_time, DEVICE_SERIAL, _recording_window
        if not is_recording:
            # Allow serial numbers OR IP:port (previous check blocked pure serials only)
            if not (DEVICE_SERIAL or "").strip():
                QMessageBox.warning(self, "No Target", "Please set the device IP/serial before recording.")
                self.prompt_update_ip()
                if not (DEVICE_SERIAL or "").strip():
                    return

            is_recording = True
            recorded_steps = []
            last_action_time = None  # first action has no leading sleep
            _recording_window = self
            self._set_recording_ui(True, 0)
            self.setWindowTitle(f"{WINDOW_TITLE} · REC")
            if hasattr(self, "mac_btn"):
                self.mac_btn.setText("Stop")
                self.mac_btn.setToolTip("Stop recording and name this macro")
            # Go to main remote so user can press real buttons
            self.stacked_widget.setCurrentIndex(0)
            # Ensure full remote is visible while recording (easier than mini)
            if self.is_minimized:
                self.exit_mini()
            QMessageBox.information(
                self,
                "Recording",
                "Recording with exact wait times.\n\n"
                "Press any remote buttons (D-pad, apps, etc.).\n"
                "When done, press Stop (or Macros → Stop Rec), then name it.",
            )
        else:
            is_recording = False
            _recording_window = None
            steps = list(recorded_steps)
            recorded_steps = []
            last_action_time = None
            self._set_recording_ui(False)
            # Restore title (dock state may re-set later)
            self.setWindowTitle(WINDOW_TITLE)
            if hasattr(self, "mac_btn"):
                self.mac_btn.setText("Macros")
                self.mac_btn.setToolTip("Open Saved Macros (while recording: stop & name)")

            if not steps:
                QMessageBox.information(self, "Empty Macro", "No buttons were recorded.")
                self.open_macros_page()
                return

            # Count real actions (exclude sleeps) for the prompt
            action_n = sum(1 for s in steps if s.get("type") != "sleep")
            label, ok = QInputDialog.getText(
                self,
                "Label Macro",
                f"Name this macro ({action_n} actions, exact waits saved):",
                text="",
            )
            if not ok or not label.strip():
                # Offer one more chance or discard
                reply = QMessageBox.question(
                    self,
                    "Discard?",
                    "No label entered. Discard this recording?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No,
                )
                if reply == QMessageBox.Yes:
                    self.open_macros_page()
                    return
                label, ok = QInputDialog.getText(
                    self, "Label Macro", "Name this macro:", text="My Macro"
                )
                if not ok or not label.strip():
                    self.open_macros_page()
                    return

            try:
                path = save_macro_labeled(label.strip(), steps)
            except Exception as e:
                QMessageBox.warning(self, "Save Failed", str(e))
                self.open_macros_page()
                return

            QMessageBox.information(
                self,
                "Macro Saved",
                f"Saved “{label.strip()}”\n({action_n} actions with exact timing)\n\n"
                f"{os.path.basename(path)}",
            )
            self.open_macros_page()

    
    def enter_hidden(self):
        if not hasattr(self, 'is_hidden'):
            self.is_hidden = False
        if not self.is_hidden:
            self.saved_geometry = self.geometry()
            self.remote_body.hide()
            self.mini_body.hide()
            self.size_grip.hide()
            self.hidden_body.show()
            self.is_hidden = True
            
            app = QApplication.instance()
            screen = app.primaryScreen()
            if screen:
                g = screen.availableGeometry()
                hw, hh = 192, 96
                x = g.x() + g.width() - hw - 8
                y = g.y() + g.height() - hh - 100
                self.setGeometry(x, y, hw, hh)

    def exit_hidden(self):
        if not getattr(self, 'is_hidden', False): return
        self.is_hidden = False
        self.hidden_body.hide()
        if self.is_minimized:
            self.mini_body.show()
        else:
            self.remote_body.show()
            self.size_grip.show()
        if self.saved_geometry:
            self.setGeometry(self.saved_geometry)

    def enter_mini(self, docked=True):
        """Switch to mini remote. docked=True snaps beside ACS HUD."""
        if not self.is_minimized:
            self.saved_geometry = self.geometry()
            self.remote_body.hide()
            self.size_grip.hide()
            self.mini_body.show()
            self.is_minimized = True
        if docked:
            self.dock_to_acs()
        else:
            self.undock_free()

    def exit_mini(self):
        """Full-size remote again."""
        if not self.is_minimized:
            return
        self.mini_body.hide()

        # --- Hidden Body ---
        self.hidden_body = QFrame(self)
        self.hidden_body.setStyleSheet("background-color: rgba(0, 0, 0, 128); border-radius: 48px;")
        hl = QVBoxLayout(self.hidden_body)
        hl.setContentsMargins(0, 0, 0, 0)
        lbl = QLabel("Chromecast", self.hidden_body)
        lbl.setStyleSheet("color: white; font-weight: bold; font-size: 16px; background: transparent;")
        lbl.setAlignment(Qt.AlignCenter)
        hl.addWidget(lbl)
        self.hidden_body.hide()
        
        # Click to restore
        self.hidden_body.mousePressEvent = lambda e: self.exit_hidden()
        self.remote_body.show()
        self.size_grip.show()
        if self.saved_geometry:
            self.setGeometry(self.saved_geometry)
        self.is_minimized = False
        self.is_docked = False
        save_config(
            DEVICE_SERIAL, self.x(), self.y(), get_protocol_mode(), docked=False
        )

    def toggle_minimize(self):
        """Legacy Mini button / menu: mini docked ↔ full."""
        if self.is_minimized:
            self.exit_mini()
        else:
            self.enter_mini(docked=True)

    def _redock_if_needed(self):
        """While docked, re-read ACS HUD position and snap again (permanent dock)."""
        if not self.is_minimized or not self.is_docked:
            return
        try:
            mx, my = dock_geometry_near_acs()
            if abs(self.x() - mx) > 2 or abs(self.y() - my) > 2:
                self.setGeometry(mx, my, MINI_W, MINI_H)
                save_config(DEVICE_SERIAL, mx, my, get_protocol_mode(), docked=True)
        except Exception:
            pass

    def dock_to_acs(self):
        """Snap mini remote beside/above ACS OSD (never screen center). Permanent."""
        if not self.is_minimized:
            self.enter_mini(docked=True)
            return
        # Remember free-float spot before snapping (only if we were free)
        if not self.is_docked:
            save_config(
                DEVICE_SERIAL, self.x(), self.y(), get_protocol_mode(),
                docked=False, free_x=self.x(), free_y=self.y()
            )
        # Always recompute from live ACS HUD file — not stale center-screen coords
        mx, my = dock_geometry_near_acs()
        self.setGeometry(mx, my, MINI_W, MINI_H)
        self.is_docked = True
        save_config(DEVICE_SERIAL, mx, my, get_protocol_mode(), docked=True)
        self.setWindowTitle(WINDOW_TITLE + " · docked")
        # Ensure redock timer is running
        try:
            if not hasattr(self, "_dock_timer") or self._dock_timer is None:
                self._dock_timer = QTimer(self)
                self._dock_timer.setInterval(15000)
                self._dock_timer.timeout.connect(self._redock_if_needed)
            if not self._dock_timer.isActive():
                self._dock_timer.start()
        except Exception:
            pass

    def undock_free(self):
        """Mini remote free-floating (movable). Restores last free position if any."""
        if not self.is_minimized:
            self.remote_body.hide()
            self.size_grip.hide()
            self.mini_body.show()
            self.is_minimized = True
        cfg = load_config()
        fx, fy = cfg.get("free_x"), cfg.get("free_y")
        if fx is None or fy is None:
            # Nudge off the dock so undock is obvious
            dx, dy = dock_geometry_near_acs()
            fx, fy = dx - 40, dy - 40
            app = QApplication.instance()
            if app:
                scr = app.screenAt(QPoint(int(fx), int(fy))) or app.primaryScreen()
                if scr:
                    g = scr.availableGeometry()
                    fx = max(g.x() + 4, min(int(fx), g.x() + g.width() - MINI_W - 4))
                    fy = max(g.y() + 4, min(int(fy), g.y() + g.height() - MINI_H - 4))
        self.setGeometry(int(fx), int(fy), MINI_W, MINI_H)
        self.is_docked = False
        save_config(
            DEVICE_SERIAL, int(fx), int(fy), get_protocol_mode(),
            docked=False, free_x=int(fx), free_y=int(fy)
        )
        self.setWindowTitle(WINDOW_TITLE + " · free")

    def toggle_dock(self):
        """Double-click: docked ↔ undocked (always stays mini)."""
        if not self.is_minimized:
            # Full remote → mini docked
            self.enter_mini(docked=True)
            return
        if self.is_docked:
            self.undock_free()
        else:
            self.dock_to_acs()

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.toggle_dock()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def mousePressEvent(self, event):
        self._drag_moved = False
        self._press_button = event.button()
        if self.is_minimized:
            if event.button() == Qt.LeftButton:
                # Undocked mini: left-drag to move. Docked: no drag (stay locked).
                if not self.is_docked:
                    self.old_pos = event.globalPosition().toPoint()
                else:
                    self.old_pos = None
            elif event.button() == Qt.RightButton:
                self.old_pos = event.globalPosition().toPoint()
        else:
            if event.button() == Qt.LeftButton:
                self.old_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if self.old_pos is None:
            return
        # Mini docked: ignore drag (must double-click to undock first)
        if self.is_minimized and self.is_docked and event.buttons() & Qt.LeftButton:
            return
        buttons_ok = False
        if self.is_minimized:
            # Free mini: left-drag moves; right-drag also moves
            if event.buttons() & (Qt.LeftButton | Qt.RightButton):
                buttons_ok = True
        else:
            if event.buttons() & Qt.LeftButton:
                buttons_ok = True
        if not buttons_ok:
            return
        delta = event.globalPosition().toPoint() - self.old_pos
        if abs(delta.x()) > 2 or abs(delta.y()) > 2:
            self._drag_moved = True
        self.move(self.pos() + delta)
        self.old_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        if self.is_minimized and event.button() == Qt.RightButton:
            self.old_pos = None
            if self._drag_moved and not self.is_docked:
                save_config(
                    DEVICE_SERIAL, self.x(), self.y(), get_protocol_mode(),
                    docked=False, free_x=self.x(), free_y=self.y()
                )
            if not self._drag_moved:
                menu = QMenu(self)
                menu.setStyleSheet(
                    "QMenu { background-color: #303134; color: white; border: 1px solid #111; } "
                    "QMenu::item:selected { background-color: #5f6368; }"
                )
                dock_action = menu.addAction(
                    "Undock (free move)" if self.is_docked else "Dock next to ACS"
                )
                hidden_action = menu.addAction("Hidden Mode")
                restore_action = menu.addAction("Restore to Normal Mode")
                exit_action = menu.addAction("Exit")
                action = menu.exec(event.globalPosition().toPoint())
                if action == dock_action:
                    self.toggle_dock()
                elif action == restore_action:
                    self.exit_mini()
                elif action == hidden_action:
                    self.enter_hidden()
                elif action == exit_action:
                    self.close()
        elif self.is_minimized and event.button() == Qt.LeftButton:
            self.old_pos = None
            if self._drag_moved and not self.is_docked:
                save_config(
                    DEVICE_SERIAL, self.x(), self.y(), get_protocol_mode(),
                    docked=False, free_x=self.x(), free_y=self.y()
                )
            elif not self._drag_moved and not event.isAccepted():
                # Single left-click on empty chrome (buttons handle their own clicks)
                # only fire nest macro if click was on background — keep simple: skip if drag
                pass
        elif not self.is_minimized and event.button() == Qt.LeftButton:
            self.old_pos = None
            if self._drag_moved:
                save_config(DEVICE_SERIAL, self.x(), self.y(), get_protocol_mode(), docked=False)

def _save_transparent_shot(widget, path):
    from PySide6.QtGui import QImage
    from PySide6.QtCore import QPoint
    scale = 2
    src = QImage(widget.size() * scale, QImage.Format_ARGB32)
    src.fill(Qt.transparent)
    painter = QPainter(src)
    painter.setRenderHint(QPainter.Antialiasing, True)
    painter.scale(scale, scale)
    widget.render(painter, QPoint())
    painter.end()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    src.save(path)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    app.setStyleSheet("QToolTip { color: #ffffff; background-color: #303134; border: 1px solid #111; border-radius: 4px; padding: 6px; font-family: 'Segoe UI', Arial; font-size: 12px; }")
    
    window = RemoteWindow()
    window.show()
    if "--screenshot" in sys.argv:
        shot_dir = r"C:\Users\Dell\script-library\web\assets"

        def _capture_and_quit():
            try:
                window.size_grip.hide()
                _save_transparent_shot(window.remote_body, os.path.join(shot_dir, "chromecast-app-remote.png"))
                _save_transparent_shot(window.remote_body, os.path.join(shot_dir, "chromecast-remote-full.png"))
                window.enter_mini(docked=False)
                window.size_grip.hide()
            except Exception as exc:
                print("screenshot full failed:", exc, flush=True)
                app.quit()
                return

            def _shot_mini():
                try:
                    _save_transparent_shot(window.mini_body, os.path.join(shot_dir, "chromecast-remote-mini.png"))
                except Exception as exc:
                    print("screenshot mini failed:", exc, flush=True)
                app.quit()

            QTimer.singleShot(300, _shot_mini)

        QTimer.singleShot(500, _capture_and_quit)
    sys.exit(app.exec())
