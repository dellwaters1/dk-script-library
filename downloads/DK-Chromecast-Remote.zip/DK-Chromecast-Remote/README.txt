DK Chromecast Remote
====================

This is the actual desktop remote from Dell's machine — the restored
floating clicker, not a mockup.

Run
---
1. Install Python 3.10+
2. pip install PySide6 androidtvremote2
3. Double-click OPEN_TV_REMOTE.bat
   or: pythonw CHROMECAST_NEST_REMOTE.pyw

First launch will ask you to pair with the Chromecast / Android TV.
